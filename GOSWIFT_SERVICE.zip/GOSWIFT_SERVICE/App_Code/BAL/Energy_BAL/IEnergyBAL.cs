﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Web;
using EntityLayer.EnergyEntity;

/// <summary>
/// Summary description for IEnergyBAL
/// </summary>

namespace BusinessLogicLayer.EnergyBAL
{
    [ServiceContract]
    public interface IEnergyBal 
    {
        #region Energy department 

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, UriTemplate = "EDApplicationStatusUpdate")]
        List<ClsOutput> EDApplicationStatusUpdate(EnergyEntity ObjParam);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, UriTemplate = "EDPaymentStatusUpdate")]
        List<ClsOutput> EDPaymentStatusUpdate(EnergyEntity ObjParam);

        //[OperationContract]
        //[WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, RequestFormat = WebMessageFormat.Json, UriTemplate = "EDQueryStatusUpdate")]
        //List<ClsOutput> EDQueryStatusUpdate(EnergyEntity ObjParam);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, UriTemplate = "EDThreePhasePaymentStatusUpdate")]
        List<ClsOutput> EDThreePhasePaymentStatusUpdate(EnergyEntity ObjParam);

        #endregion
    }
}

