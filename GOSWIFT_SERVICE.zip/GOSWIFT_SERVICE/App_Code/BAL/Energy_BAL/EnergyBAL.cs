﻿using BusinessLogicLayer.EnergyBAL;
using DataAcessLayer.EnergyDAL;
using EntityLayer.EnergyEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for EnergyBAL
/// </summary>

namespace BusinessLogicLayer.EnergyBAL
{
    public class EnergyBal : IEnergyBal
    {
        EnergyDAL obj = new EnergyDAL();

        public List<ClsOutput> EDApplicationStatusUpdate(EnergyEntity ObjParam)
        {
            return obj.EDApplicationStatusUpdate(ObjParam);
        }

        public List<ClsOutput> EDPaymentStatusUpdate(EnergyEntity ObjParam)
        {
            return obj.EDPaymentStatusUpdate(ObjParam);
        }

        //public List<ClsOutput> EDQueryStatusUpdate(EnergyEntity ObjParam)
        //{
        //    return obj.EDQueryStatusUpdate(ObjParam);
        //}

        public List<ClsOutput> EDThreePhasePaymentStatusUpdate(EnergyEntity ObjParam)
        {
            return obj.EDThreePhasePaymentStatusUpdate(ObjParam);
        }
    }
}


