﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityLayer.SWPIntegration
{
   public class SWPProfile
    {
     //public  string proposalid { get; set; }
     //public string unit_type { get; set; }
    // public string unit_name { get; set; }

     public string Investor_Name { get; set; }
     public string Investor_Addrss { get; set; }
     public string Investor_EmailId { get; set; }
     public double Investor_MobileNo { get; set; }
     public string Unit_name { get; set; }
     public string Unit_Address { get; set; }
     public string UnitEmailId { get; set; }
     public double UnitMobileNo { get; set; }
     //public string ULBCode { get; set; }
     //public string FirmName { get; set; }
     //public string FirmAddress { get; set; }
         
     //public string promoter_FirstName { set; get; }
     //public string promoter_MiddleName { set; get; }
     //public string promoter_LastName { set; get; }

     //public string comm_address { get; set; }
     //public string comm_mobile_no { get; set; }
     //public string comm_email { get; set; }
    }
}
