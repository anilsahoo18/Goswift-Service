﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using SWP_Services.DAL.Data;
using EntityLayer.DrugEntity;
using System.Configuration;
using System.Web.Script.Serialization;

/// <summary>
/// Summary description for DrugLicenseDAL
/// </summary>

namespace SWP_Services.DAL
{
    public class DrugLicenseDAL : IDrugLicenseDAL
    {
        string connectionString = ConfigurationManager.ConnectionStrings[DataBaseHelper.ConnectionString].ConnectionString;
        string RetValue;
        object param = new object();
       

        readonly string strDRUGSecurityKey = ConfigurationManager.AppSettings["DRUGSecurityKey"].ToString();

        public List<ClsOutput> DLApplicationStatusUpdate(DrugEntity ObjParam)
        {
            ClsOutput objResponse = new ClsOutput();
            List<ClsOutput> lstResponse = new List<ClsOutput>();
            try
            {
                ///// Write request log for each request.
                string strInput = "(Request)---Application No :- " + ObjParam.ApplicationNo.Trim() + " Security Key:- " + ObjParam.SecurityKey.Trim();
                Util.LogRequestResponse("DRUG", "DLApplicationStatusUpdate", strInput);

                /*--------------------------------------------------------------------*/
                ////// Validation Section
                /*--------------------------------------------------------------------*/
                int intValid = 0;

                #region Validation

                if (ObjParam.SecurityKey.Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Security key should not be blank.";
                    intValid = 1;
                }
                else if (ObjParam.SecurityKey.Trim() != strDRUGSecurityKey)
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Invalid security key.";
                    intValid = 1;
                }
                else if (ObjParam.ApplicationNo.Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Application number should not be blank.";
                    intValid = 1;
                }
                else if (ObjParam.ServiceId.ToString().Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Service id should not be blank.";
                    intValid = 1;
                }
                else if (ObjParam.Status.ToString().Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Status should not be blank.";
                    intValid = 1;
                }
                else if (ObjParam.Remarks.Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Remarks should not be blank.";
                    intValid = 1;
                }

                if (ObjParam.Status.ToString().Trim() == "3") //// Rejected
                {
                    if (ObjParam.ReferenceDocFileLink.Trim() == "")
                    {
                        objResponse.Status = 1;
                        objResponse.OutMessage = "Reference document link should not be blank.";
                        intValid = 1;
                    }
                }

                if (ObjParam.Status.ToString().Trim() == "2") //// Approved
                {
                    if (ObjParam.ApprovalDocFileLink.Trim() == "")
                    {
                        objResponse.Status = 1;
                        objResponse.OutMessage = "Approval document link should not be blank.";
                        intValid = 1;
                    }
                }


                #endregion

                /*--------------------------------------------------------------------*/

                if (intValid == 0)
                {
                    object[] objArray = new object[] { "@P_VCH_ACTION", "ASU",
                                                       "@P_VCH_APPLICATION_UNQ_KEY",ObjParam.ApplicationNo,
                                                       "@P_INT_SERVICEID",ObjParam.ServiceId,
                                                       "@P_INT_STATUS",ObjParam.Status,
                                                       "@P_VCH_CERTIFICATE_FILENAME",ObjParam.ApprovalDocFileLink,
                                                       "@P_VCH_REMARK",ObjParam.Remarks,
                                                       "@P_VCH_REFERENCE_DOC_NAME",ObjParam.ReferenceDocFileLink
                                                    };

                    RetValue = SqlHelper.ExecuteNonQuery(connectionString, "USP_DRUG_License_Service", out param, objArray).ToString();

                    if (param.ToString() == "1")
                    {
                        objResponse.Status = 2;
                        objResponse.OutMessage = "Success";
                    }
                    else if (param.ToString() == "4")
                    {
                        objResponse.Status = 4;
                        objResponse.OutMessage = "Invalid Application Number.";
                    }
                    else if (param.ToString() == "5")
                    {
                        objResponse.Status = 5;
                        objResponse.OutMessage = "Invalid Service Id.";
                    }
                    else
                    {
                        objResponse.Status = 0;
                        objResponse.OutMessage = "Some Error Occured.Please Contact Administrator.";
                    }
                }

                /*-----------------------------------------------------------*/
                ///// Write response log for each request.
                JavaScriptSerializer jsonSerialiser = new JavaScriptSerializer();
                var json = jsonSerialiser.Serialize(objResponse);
                string strOutput = "(Response)--- Status :- " + intValid.ToString() + " OutputString:- " + json;
                Util.LogRequestResponse("DRUG", "DLApplicationStatusUpdate", strOutput);
                /*-----------------------------------------------------------*/
            }
            catch (SqlException ex)
            {
                objResponse.Status = 3;
                objResponse.OutMessage = ex.Message;
                Util.LogError(ex, "DRUG");
            }
            lstResponse.Add(objResponse);
            return lstResponse;
        }

        public List<ClsOutput> DLPaymentStatusUpdate(DrugEntity ObjParam)
        {
            ClsOutput objResponse = new ClsOutput();
            List<ClsOutput> lstResponse = new List<ClsOutput>();
            try
            {
                ///// Write request log for each request.
                string strInput = "(Request)---Application No :- " + ObjParam.ApplicationNo.Trim() + " Security Key:- " + ObjParam.SecurityKey.Trim() + "Service Id :- " + ObjParam.ServiceId.ToString() + "Payment Status :- " + ObjParam.PaymentStatus.ToString();
                Util.LogRequestResponse("DRUG", "DLPaymentStatusUpdate", strInput);
                /*--------------------------------------------------------------------*/
                ////// Validation Section
                /*--------------------------------------------------------------------*/

                int intValid = 0;
                #region Validation

                if (ObjParam.SecurityKey.Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Security key should not be blank.";
                    intValid = 1;
                }
                else if (ObjParam.SecurityKey.Trim() != strDRUGSecurityKey)
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Invalid security key.";
                    intValid = 1;
                }
                else if (ObjParam.ApplicationNo.Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Application number should not be blank.";
                    intValid = 1;
                }
                else if (ObjParam.ServiceId.ToString().Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Service id should not be blank.";
                    intValid = 1;
                }
                else if (ObjParam.PaymentStatus.ToString().Trim() != "1")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Invalid payment status.";
                    intValid = 1;
                }
                else if (ObjParam.PaymentAmount.ToString().Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Payment amount should not be blank.";
                    intValid = 1;
                }



                #endregion

                if (intValid == 0)
                {
                    object[] arr = new object[] { "@P_VCH_ACTION","PU",
                                                  "@P_VCH_APPLICATION_UNQ_KEY",ObjParam.ApplicationNo,
                                                  "@P_INT_SERVICEID",ObjParam.ServiceId,
                                                  "@P_INT_PAYMENT_STATUS",ObjParam.PaymentStatus,
                                                  "@P_NUM_PAYMENT_AMOUNT",ObjParam.PaymentAmount,
                                                  "@P_VCH_PAYMENT_ACKNOWLEDGEMENT_NO",ObjParam.BankTransId,
                                                  "@P_VCH_CHALLAN_NO",ObjParam.ChallanNo
                                                };

                    RetValue = SqlHelper.ExecuteNonQuery(connectionString, "USP_DRUG_License_Service", out param, arr).ToString();

                    if (param.ToString() == "1")
                    {
                        objResponse.Status = 2;
                        objResponse.OutMessage = "Success";
                    }
                    else if (param.ToString() == "4")
                    {
                        objResponse.Status = 4;
                        objResponse.OutMessage = "Invalid Application Number.";
                    }
                    else if (param.ToString() == "5")
                    {
                        objResponse.Status = 5;
                        objResponse.OutMessage = "Invalid Service Id.";
                    }
                    else
                    {
                        objResponse.Status = 0;
                        objResponse.OutMessage = "Some Error Occured.Please Contact Administrator.";
                    }
                }

                /*-----------------------------------------------------------*/
                ///// Write response log for each request.
                JavaScriptSerializer jsonSerialiser = new JavaScriptSerializer();
                var json = jsonSerialiser.Serialize(objResponse);
                string strOutput = "(Response)--- Status :- " + intValid.ToString() + " OutputString:- " + json;
                Util.LogRequestResponse("DRUG", "DLPaymentStatusUpdate", strOutput);
                /*-----------------------------------------------------------*/

            }
            catch (SqlException ex)
            {
                objResponse.Status = 3;
                objResponse.OutMessage = ex.Message;
                Util.LogError(ex, "DRUG");
            }
            lstResponse.Add(objResponse);
            return lstResponse;
        }

        public List<ClsOutput> DLQueryStatusUpdate(DrugEntity ObjParam)
        {
            ClsOutput objResponse = new ClsOutput();
            List<ClsOutput> lstResponse = new List<ClsOutput>();

            try
            {
                ///// Write request log for each request.
                string strInput = "(Request)---Application No :- " + ObjParam.ApplicationNo.Trim() + " Security Key:- " + ObjParam.SecurityKey.Trim();
                Util.LogRequestResponse("DRUG", "DLQueryStatusUpdate", strInput);

                /*--------------------------------------------------------------------*/
                ////// Validation Section
                /*--------------------------------------------------------------------*/
                int intValid = 0;

                #region Validation

                if (ObjParam.SecurityKey.Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Security key should not be blank.";
                    intValid = 1;
                }
                else if (ObjParam.SecurityKey.Trim() != strDRUGSecurityKey)
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Invalid security key.";
                    intValid = 1;
                }
                else if (ObjParam.ApplicationNo.Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Application number should not be blank.";
                    intValid = 1;
                }
                else if (ObjParam.ServiceId.ToString().Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Service id should not be blank.";
                    intValid = 1;
                }
                else if (ObjParam.QueryStatus.ToString().Trim() == "")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Query status should not be blank.";
                    intValid = 1;
                }
                else if (ObjParam.QueryStatus.ToString().Trim() != "5" && ObjParam.QueryStatus.ToString().Trim() != "6")
                {
                    objResponse.Status = 1;
                    objResponse.OutMessage = "Invalid query status.";
                    intValid = 1;
                }

                #endregion

                /*--------------------------------------------------------------------*/

                if (intValid == 0)
                {
                    object[] arr = new object[] {  "@P_VCH_ACTION","QU",
                                                       "@P_VCH_APPLICATION_UNQ_KEY",ObjParam.ApplicationNo,
                                                       "@P_INT_SERVICEID",ObjParam.ServiceId,
                                                       "@P_INT_QUERY_STATUS",ObjParam.QueryStatus
                                                    };

                    RetValue = SqlHelper.ExecuteNonQuery(connectionString, "USP_DRUG_License_Service", out param, arr).ToString();

                    if (param.ToString() == "1")
                    {
                        objResponse.Status = 2;
                        objResponse.OutMessage = "Success";
                    }
                    else if (param.ToString() == "4")
                    {
                        objResponse.Status = 4;
                        objResponse.OutMessage = "Invalid Application Number.";
                    }
                    else if (param.ToString() == "5")
                    {
                        objResponse.Status = 5;
                        objResponse.OutMessage = "Invalid Service Id.";
                    }
                    else
                    {
                        objResponse.Status = 0;
                        objResponse.OutMessage = "Some Error Occured.Please Contact Administrator.";
                    }
                }

                /*-----------------------------------------------------------*/
                ///// Write response log for each request.
                JavaScriptSerializer jsonSerialiser = new JavaScriptSerializer();
                var json = jsonSerialiser.Serialize(objResponse);
                string strOutput = "(Response)--- Status :- " + intValid.ToString() + " OutputString:- " + json;
                Util.LogRequestResponse("DRUG", "DLQueryStatusUpdate", strOutput);
                /*-----------------------------------------------------------*/
            }
            catch (SqlException ex)
            {
                objResponse.Status = 3;
                objResponse.OutMessage = ex.Message;
                Util.LogError(ex, "DRUG");
            }

            lstResponse.Add(objResponse);
            return lstResponse;
        }

        //public List<DrugLicenseUserProfile> GettRetailUserProfileDetails(AuthStatus objUser)
        //{
        //    SqlDataReader reader;
        //    List<DrugLicenseUserProfile> list = new List<DrugLicenseUserProfile>();
        //    object[] arr = new object[] {    "P_Action",objUser.Action,
        //                                     "P_UserID",objUser.UserID
        //                                };
        //    try
        //    {
        //        reader = (SqlDataReader)SqlHelper.ExecuteReader(connectionString, "USP_DRUG_LICENSE", arr);
        //        list = reader.DataReaderMapToList<DrugLicenseUserProfile>(MappingDirection.Auto);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }
        //    finally
        //    {
        //        reader = null;
        //    }

        //    return list;
        //}

        //public List<RetailPushDataStatus> SWPPushDataReatail(RetailPushData objDATA)
        //{
        //    RetailPushDataStatus objResponse = new RetailPushDataStatus();
        //    List<RetailPushDataStatus> lstResponse = new List<RetailPushDataStatus>();
        //    DataAcessLayer.SWPIntegrationDAL.DALApplicationDetails objUser = new DataAcessLayer.SWPIntegrationDAL.DALApplicationDetails();
        //    try
        //    {
        //        object[] objArray = new object[] { "P_Action", objDATA.Action,
        //                                           "P_ProposalID",objDATA.ProposalID,
        //                                           "P_VCH_INVESTOR_NAME",objDATA.InvstorName,
        //                                           "P_VCH_APPLICATION_UNQ_KEY",objDATA.ApplicationNumber,
        //                                           "P_SERVICEID",objDATA.ServiceID,
        //                                           "P_INT_STATUS",objDATA.ApplicationStatus,
        //                                           "P_INT_PAYMENT_STATUS",objDATA.PaymentStatus,
        //                                           "P_VCH_PAYMENT_ACKNOWLEDGEMENT_NO",objDATA.PaymentTransactionID,
        //                                           "P_NUM_PAYMENT_AMOUNT", objDATA.PaymentAmount,
        //                                           "P_VCH_CERTIFICATE_FILENAME",objDATA.CertificateName,
        //                                           "P_VCH_REFERENCE_DOC_NAME",objDATA.ReferenceDocName,
        //                                           "P_VCH_REMARK",objDATA.Remark,
        //                                           "P_INT_ESCALATION_ID",objDATA.EscalationID,
        //                                           "P_VCH_ULB_CODE",objDATA.ULBCode,
        //                                           "P_INT_CREATEDBY",objDATA.UserID                   
        //                                        };

        //        RetValue = SqlHelper.ExecuteNonQuery(connectionString, "USP_DRUG_LICENSE", out param, objArray).ToString();
        //        if (param.ToString() == "1")
        //        {
        //            objResponse.Status = 1;
        //            objResponse.StatusMsg = "Success";
        //        }
        //        else
        //        {
        //            objResponse.Status = 0;
        //            objResponse.StatusMsg = "Fail";
        //        }
        //        lstResponse.Add(objResponse);
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw new Exception(ex.Message.ToString());
        //    }

        //    return lstResponse;
        //}
    }
}