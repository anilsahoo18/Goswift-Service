﻿using EntityLayer.EnergyEntity;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for IEnergyDAL
/// </summary>
/// 

namespace DataAcessLayer.EnergyDAL
{
    public interface IEnergyDAL
    {
        #region Energy department

        List<ClsOutput> EDApplicationStatusUpdate(EnergyEntity ObjParam);

        List<ClsOutput> EDPaymentStatusUpdate(EnergyEntity ObjParam);

        //List<ClsOutput> EDQueryStatusUpdate(EnergyEntity ObjParam);

        List<ClsOutput> EDThreePhasePaymentStatusUpdate(EnergyEntity ObjParam);

        #endregion
    }
}
